<?php
require('fpdf186/fpdf.php'); // Inclure FPDF

// Vérifier si les données sont envoyées via le formulaire
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupérer les valeurs du formulaire
    $type = $_POST['type'];
    $technologie = $_POST['technologie'];
    $puissance = $_POST['puissance'];
    $puissance_autre = isset($_POST['puissance-autre']) ? $_POST['puissance-autre'] : '';
    $autonomie = $_POST['autonomie'];
    $tension_sortie = $_POST['tension-sortie'];
    $tension_entree = $_POST['tension-entree'];
    $frequence_sortie = $_POST['frequence-sortie'];
    $frequence_entree = $_POST['frequence-entree'];
    $connexions_sortie = $_POST['connexions-sortie'];
    $connexions_sortie_autre = isset($_POST['connexions-sortie-autre']) ? $_POST['connexions-sortie-autre'] : '';
    $connexions_entree = $_POST['connexions-entree'];
    $connexions_entree_autre = isset($_POST['connexions-entree-autre']) ? $_POST['connexions-entree-autre'] : '';
    $phase_sortie = $_POST['phase-sortie'];
    $bruit_audible = $_POST['bruit-audible'];

    // Création du PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Description de l\'Onduleur', 0, 1, 'C');
    $pdf->Ln(10);
    
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Type: ' . $type, 0, 1);
    $pdf->Cell(0, 10, 'Technologie: ' . $technologie, 0, 1);
    $pdf->Cell(0, 10, 'Puissance: ' . ($puissance === 'autre' ? $puissance_autre : $puissance), 0, 1);
    $pdf->Cell(0, 10, 'Autonomie: ' . $autonomie, 0, 1);
    $pdf->Cell(0, 10, 'Tension de Sortie: ' . $tension_sortie, 0, 1);
    $pdf->Cell(0, 10, 'Tension d\'Entrée: ' . $tension_entree, 0, 1);
    $pdf->Cell(0, 10, 'Fréquence de Sortie: ' . $frequence_sortie, 0, 1);
    $pdf->Cell(0, 10, 'Fréquence d\'Entrée: ' . $frequence_entree, 0, 1);
    $pdf->Cell(0, 10, 'Connexions de Sortie: ' . ($connexions_sortie === 'autre' ? $connexions_sortie_autre : $connexions_sortie), 0, 1);
    $pdf->Cell(0, 10, 'Connexions d\'Entrée: ' . ($connexions_entree === 'autre' ? $connexions_entree_autre : $connexions_entree), 0, 1);
    $pdf->Cell(0, 10, 'Phase de Sortie: ' . $phase_sortie, 0, 1);
    $pdf->Cell(0, 10, 'Bruit Audible: ' . $bruit_audible, 0, 1);

    // Générer le PDF et l'envoyer au navigateur
    $pdf->Output('F', 'téléchargement/onduleur.pdf');
} else {
    echo 'Aucune donnée reçue.';
}
?>
