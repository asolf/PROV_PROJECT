<?php
require('fpdf186/fpdf.php');

// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "history";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

class PDF extends FPDF
{
    function Footer()
    {
        $this->SetY(-20);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }
}

$pdf = new PDF();
$pdf->SetTitle('imprimente');
$pdf->AddPage();

$pdf->SetFont('Arial', '', 16);
$pdf->Cell(0, 10, 'ROYAUME DU MAROC PROVINCE DE FQUIH BEN SALAH', 0, 1, 'L');
$pdf->SetFont('Arial', 'BU', 16);
$pdf->Cell(0, 10, 'Printer Description', 0, 1, 'C');

function output($option, $input) {
    if (isset($_POST[$option])) {
        if ($_POST[$option] == 'autre' && isset($_POST[$input])) {
            return $_POST[$input];
        } else {
            return $_POST[$option];
        }
    }
    return ''; // Retourne une chaîne vide si l'option n'existe pas dans $_POST
}
$type_imprimante = output('type_imprimante', 'other_type_imprimante');
$marque_imprimante = output('marque_imprimante', 'other_marque_imprimante');
$resolution_impression = output('impression_dpi', 'other_impression_dpi');
$resolution_numerisation = output('numerisation_dpi', 'other_numerisation_dpi');
$mem_ram = output('mem_ram', 'other_mem_ram');
$disque_dur = output('ddur', 'other_ddur');
$carte_sd = output('sdcard', 'other_sdcard');
$os = output('os', 'other_os');
$protocoles = output('protocoles', 'other_protocoles');
$langues = output('langues', 'other_langues');

$h = 15;
$w = 60;
$pdf->SetFont('Arial', 'BU', 12);
$pdf->Ln();

$liste = array(
    'Type d\'imprimante' => $type_imprimante,
    'Marque' => $marque_imprimante,
    utf8_decode('Résolution d\'impression') => $resolution_impression,
    utf8_decode('Résolution de numérisation') => $resolution_numerisation,
    utf8_decode('Mémoire RAM') => $mem_ram,
    utf8_decode('Disque dur') => $disque_dur,
    utf8_decode('Carte SD') => $carte_sd,
    utf8_decode('Système d\'exploitation') => $os,
    utf8_decode('Protocoles') => $protocoles,
    utf8_decode('Langues supportées') => utf8_decode($langues),
);

foreach ($liste as $x => $y) {
    $pdf->SetX(30);
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell($w, $h, $x, 1, 0, 'C');
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell($w, $h, $y, 1, 1, 'C');
}

$pdf->Ln();
$document_name = mysqli_real_escape_string($conn, 'description_imprimente.pdf');
$document_link = mysqli_real_escape_string($conn, 'téléchargement/description_imprimente.pdf');



$pdf->Output('I', '');
$pdf->Output('F', 'téléchargement/description_imprimente.pdf');

// Insérer une nouvelle entrée dans la table history
$sql = "INSERT INTO document_history (document_name, document_link) VALUES ('$document_name', '$document_link')";


if ($conn->query($sql) === TRUE) {
    echo "PDF ajouté à l'historique avec succès.";
} else {
    echo "Erreur lors de l'ajout à l'historique : " . $conn->error;
}

$conn->close();

?>
