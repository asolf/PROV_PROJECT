<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "history";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all documents from the database
$result = mysqli_query($conn, "SELECT * FROM document_history ORDER BY download_date DESC");

$documents = [];
while ($row = mysqli_fetch_assoc($result)) {
    $documents[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Historique des Documents Téléchargés</title>
    <script src="https://kit.fontawesome.com/0ddc501cbc.js" crossorigin="anonymous"></script>
    <style>
        .share-buttons {
            display: none;
            margin-top: 10px;
        }
        .share-button {
            display: inline-block;
            margin-right: 10px;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 0;
            background-color: #f4f4f4;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            background-color: #fff;
            margin: 10px 0;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        .date {
            color: #666;
            font-size: 0.9em;
        }
    </style>
</head>
<body>

<h1>Historique des Documents Téléchargés</h1>

<ul>
    <?php foreach ($documents as $document): ?>
    <li>
        <a href="<?php echo htmlspecialchars($document['document_link']); ?>" target="_blank" class="document-link">
            <?php echo htmlspecialchars($document['document_name']); ?>
        </a>
        <span class="date">
            - Téléchargé le <?php echo date('d/m/Y H:i:s', strtotime($document['download_date'])); ?>
        </span>
        <button class="shareBtn">Partager</button>

        <div class="share-buttons">
            <a href="#" class="emailBtn share-button">Email</a>
            <a href="#" class="whatsappBtn share-button">WhatsApp</a>
        </div>
    </li>
    <?php endforeach; ?>
</ul>

<script>
    document.querySelectorAll('.shareBtn').forEach(function(button) {
        button.addEventListener('click', function() {
            var shareButtons = this.nextElementSibling;
            if (shareButtons.style.display === 'none' || shareButtons.style.display === '') {
                shareButtons.style.display = 'block';
            } else {
                shareButtons.style.display = 'none';
            }
        });
    });

    document.querySelectorAll('.emailBtn').forEach(function(button) {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            //var link = this.closest('li').querySelector('.document-link').href;
            var link =<a href="Téléchargement/Description_Imprimante_1724755398.pdf"></a>;
            var subject = "Je voulais partager cela avec vous";
            var body = "Veuillez trouver ci-joint le fichier PDF. Vous pouvez le télécharger ici : " + link;
            window.location.href = "mailto:aouatif4elhadi@gmail.com?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
        });
        document.querySelector('.emailBtn').forEach(function(button){
            button.addEventListener('click',function(event){
                event.preventDefault();
                var link=<a href="Téléchargement/Description_Imprimante_1724755398.pdf"></a>;
                var subject="Je voulais partager cela avec vous";
                var body ="Veuillez trouver ci-joint le fichier PDF.Vous pouvez le télécharger ici "+link;
                window.location.href="mailto:thisatest@gmail.com" ;
                so.how =just.href="mailto:thissatestand how to make "

            })
        })
    });

    document.querySelectorAll('.whatsappBtn').forEach(function(button) {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            var link = this.closest('li').querySelector('.document-link').href;
            var text = "Voici le lien vers le fichier PDF : " + link;
            var url = "https://wa.me/?text=" + encodeURIComponent(text);
            window.open(url, '_blank');
        });
    });
</script>
</body>
</html>
