<?php
require('fpdf186/fpdf.php');

$pdf = new FPDF();
$pdf->AddPage();

$pdf->SetFont('Arial', 'B', 16);

$pdf->Cell(0, 10, 'Détails des Consommables de Matériel', 0, 1, 'C');
$pdf->Ln(10);

function addSection($pdf, $title, $fields) {
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, $title, 0, 1);
    $pdf->SetFont('Arial', '', 12);

    foreach ($fields as $label => $value) {
        // Afficher "Non précisé" si la valeur est vide
        $displayValue = empty($value) ? 'Non précisé' : $value;
        $pdf->Cell(50, 10, $label . ':', 0, 0);
        $pdf->Cell(0, 10, $displayValue, 0, 1);
    }

    $pdf->Ln(5);
}

// Cartouches d'encre
addSection($pdf, 'Cartouches d\'encre', [
    'Marque' => $_POST['encre_marque'] ?? '',
    'Modèle' => $_POST['encre_modele'] ?? '',
    'Couleur' => $_POST['encre_couleur'] ?? '',
    'Capacité (mL)' => $_POST['encre_capacite'] ?? '',
    'Compatibilité' => $_POST['encre_compatibilite'] ?? '',
    'Quantité' => $_POST['encre_quantite'] ?? ''
]);

// Toner
addSection($pdf, 'Toner', [
    'Marque' => $_POST['toner_marque'] ?? '',
    'Modèle' => $_POST['toner_modele'] ?? '',
    'Couleur' => $_POST['toner_couleur'] ?? '',
    'Capacité (pages)' => $_POST['toner_capacite'] ?? '',
    'Compatibilité' => $_POST['toner_compatibilite'] ?? '',
    'Quantité' => $_POST['toner_quantite'] ?? ''
]);

// Bouteille d'encre
addSection($pdf, 'Bouteille d\'encre', [
    'Marque' => $_POST['bouteille_marque'] ?? '',
    'Couleur' => $_POST['bouteille_couleur'] ?? '',
    'Volume (mL)' => $_POST['bouteille_volume'] ?? '',
    'Compatibilité' => $_POST['bouteille_compatibilite'] ?? '',
    'Quantité' => $_POST['bouteille_quantite'] ?? ''
]);

// Ruban
addSection($pdf, 'Ruban', [
    'Marque' => $_POST['ruban_marque'] ?? '',
    'Largeur (mm)' => $_POST['ruban_largeur'] ?? '',
    'Longueur (m)' => $_POST['ruban_longueur'] ?? '',
    'Couleur' => $_POST['ruban_couleur'] ?? '',
    'Compatibilité' => $_POST['ruban_compatibilite'] ?? '',
    'Quantité' => $_POST['ruban_quantite'] ?? ''
]);

// Tête d'impression
addSection($pdf, 'Tête d\'impression', [
    'Marque' => $_POST['tete_marque'] ?? '',
    'Modèle' => $_POST['tete_modele'] ?? '',
    'Type d\'imprimante' => $_POST['tete_type'] ?? '',
    'Compatibilité' => $_POST['tete_compatibilite'] ?? '',
    'Quantité' => $_POST['tete_quantite'] ?? ''
]);

// Papier
addSection($pdf, 'Papier', [
    'Type de papier' => $_POST['papier_type'] ?? '',
    'Format' => $_POST['papier_format'] ?? '',
    'Grammage (g/m²)' => $_POST['papier_grammage'] ?? '',
    'Finition' => $_POST['papier_finition'] ?? '',
    'Quantité (feuilles)' => $_POST['papier_quantite'] ?? ''
]);

// Cartouche
addSection($pdf, 'Cartouche', [
    'Marque' => $_POST['cartouche_marque'] ?? '',
    'Modèle' => $_POST['cartouche_modele'] ?? '',
    'Type' => $_POST['cartouche_type'] ?? '',
    'Couleur' => $_POST['cartouche_couleur'] ?? '',
    'Compatibilité' => $_POST['cartouche_compatibilite'] ?? '',
    'Quantité' => $_POST['cartouche_quantite'] ?? ''
]);

// Kit de maintenance
addSection($pdf, 'Kit de maintenance', [
    'Marque' => $_POST['kit_marque'] ?? '',
    'Contenu' => $_POST['kit_contenu'] ?? '',
    'Compatibilité' => $_POST['kit_compatibilite'] ?? '',
    'Quantité' => $_POST['kit_quantite'] ?? ''
]);

// Envoyer le fichier PDF au navigateur
$pdf->Output('F', 'téléchargement/consommables.pdf');
?>
