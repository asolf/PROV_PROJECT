<?php
require('fpdf186/fpdf.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Création d'une instance FPDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);

    // Titre
    $pdf->Cell(0, 10, utf8_decode('Formulaire de Choix de Périphériques'), 0, 1, 'C');

    // Choix du Pack
    $package = $_POST['package'] ?? '';
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, utf8_decode('Type de Périphérique:'), 0, 1);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, ucfirst($package), 0, 1);
    $x=50;

    // Caractéristiques spécifiques
    if ($package === 'pack' || $package === 'mouse') {
        // Souris
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, utf8_decode('Caractéristiques de la Souris:'), 0, 1);
        $pdf->SetFont('Arial', '', 12);

        // Type de Souris
        $mouse_types = isset($_POST['mouse-type']) ? $_POST['mouse-type'] : '';
        $pdf->Cell($x, 10, 'Type de Souris:', 0, 0);
            $pdf->Cell(0, 10,  ucfirst($mouse_types), 0, 1);
        

        // Nombre de Boutons
        $mouse_buttons = isset($_POST['mouse-buttons']) ? $_POST['mouse-buttons'] : '';
        $pdf->Cell($x, 10, 'Nombre de Boutons:', 0, 0);
            $pdf->Cell(0, 10, $mouse_buttons, 0, 1);
        // Connectivité
        $mouse_connectivity = isset($_POST['mouse-connectivity'])  ? $_POST['mouse-connectivity'] : '';
        $pdf->Cell($x, 10, utf8_decode('Connectivité:'), 0, 0);
            $pdf->Cell(0, 10,ucfirst($mouse_connectivity), 0, 1);
        
    }

    if ($package === 'pack' || $package === 'keyboard') {
        // Clavier
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, utf8_decode('Caractéristiques du Clavier:'), 0, 1);
        $pdf->SetFont('Arial', '', 12);

        // Type de Clavier
        $keyboard_types = isset($_POST['keyboard-type'])  ? $_POST['keyboard-type'] : '';
        $pdf->Cell($x, 10, 'Type de Clavier:', 0, 0);
            $pdf->Cell(0, 10, ucfirst($keyboard_types), 0, 1);
        

        // Rétroéclairage
        $keyboard_backlight = isset($_POST['keyboard-backlight'])  ? $_POST['keyboard-backlight'] : '';
        $pdf->Cell($x, 10, utf8_decode('Rétroéclairage:'), 0, 0);
            $pdf->Cell(0, 10, ucfirst($keyboard_backlight ), 0, 1);
        
        // Connectivité
        $keyboard_connectivity = isset($_POST['keyboard-connectivity'])  ? $_POST['keyboard-connectivity'] : '';
        $pdf->Cell($x, 10, utf8_decode('Connectivité:'), 0, 0);
            $pdf->Cell(0, 10, ucfirst($keyboard_connectivity), 0, 1);
        
    }
    // Génération du fichier PDF
    $pdf->Output('F', 'téléchargement/formulaire.pdf');
} else {
    echo 'Aucune donnée reçue.';
}
