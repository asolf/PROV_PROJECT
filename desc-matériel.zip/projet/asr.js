let availableKeywords = [
  { name: "Ordinateur", link: "ordinateur.html" },
  { name: "Imprimante", link: "imprimante.html" },
  { name: "Consommables", link: "consomable.html" },
  { name: "Écran / Moniteur", link: "Ecran-moniteur.html" },
  { name: "Onduleur", link: "onduleur.html" },
  { name: "Périphérique", link: "périphérique.html" },
  { name: "Tablette graphique", link: "tablette-graphique.html" },
  { name: "Image & Son", link: "image&son.html" },
  { name: "Réseaux", link: "réseau.html" },
  { name: "Téléphonie", link: "ordinateur.html" }, // Corrige le lien si besoin
];

const resultsBox = document.querySelector(".result-box");
const inputBox = document.getElementById("input-box");

inputBox.onkeyup = function () {
  let result = [];
  let input = inputBox.value;
  if (input.length) {
    result = availableKeywords.filter((keyword) => {
      return keyword.name.toLowerCase().includes(input.toLowerCase());
    });
    console.log(result);
  }
  display(result);

  if (!result.length) {
    resultsBox.innerHTML = "";
  }
};

function display(result) {
  const content = result.map((item) => {
    return (
      "<li onclick=selectInput('" + item.link + "')>" + item.name + "</li>"
    );
  });
  resultsBox.innerHTML = "<ul>" + content.join("") + "</ul>";
}

function selectInput(link) {
  window.location.href = link;
}
