<?php
require('fpdf186/fpdf.php');

// Création d'une instance de FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

// Titre du document
$pdf->Cell(0, 10, utf8_decode('Description de Vidéo Projecteur'), 0, 1, 'C');
$pdf->Ln(10);

// Fonction pour ajouter des données au PDF
function addField($pdf, $label, $value) {
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, $label . ':', 0, 1);
    $pdf->SetFont('Arial', '', 12);
    $pdf->MultiCell(0, 10, $value);
    $pdf->Ln(5);
}

// Récupération des données du formulaire
$resolution = $_POST['resolution'];
$resolution_autre = isset($_POST['resolution_autre']) ? $_POST['resolution_autre'] : '';

$luminosite = $_POST['luminosite'];
$luminosite_autre = isset($_POST['luminosite_autre']) ? $_POST['luminosite_autre'] : '';

$lampe = $_POST['lampe'];
$lampe_autre = isset($_POST['lampe_autre']) ? $_POST['lampe_autre'] : '';

$rapport_projection = $_POST['rapport_projection'];
$rapport_projection_autre = isset($_POST['rapport_projection_autre']) ? $_POST['rapport_projection_autre'] : '';

$taille_image = $_POST['taille_image'];
$taille_image_autre = isset($_POST['taille_image_autre']) ? $_POST['taille_image_autre'] : '';

$systeme_projection = $_POST['systeme_projection'];
$systeme_projection_autre = isset($_POST['systeme_projection_autre']) ? $_POST['systeme_projection_autre'] : '';

$haut_parleur = $_POST['haut_parleur'];
$haut_parleur_autre = isset($_POST['haut_parleur_autre']) ? $_POST['haut_parleur_autre'] : '';

$poids = $_POST['poids'];
$poids_autre = isset($_POST['poids_autre']) ? $_POST['poids_autre'] : '';

$connexions = $_POST['connexions'];

// Ajout des données au PDF
addField($pdf, utf8_decode('Résolution'), $resolution . ($resolution_autre ? ' - ' . $resolution_autre : ''));
addField($pdf, utf8_decode('Luminosité'), $luminosite . ($luminosite_autre ? ' - ' . $luminosite_autre : ''));
addField($pdf, utf8_decode('Lampe'), $lampe . ($lampe_autre ? ' - ' . $lampe_autre : ''));
addField($pdf, utf8_decode('Rapport de Projection'), $rapport_projection . ($rapport_projection_autre ? ' - ' . $rapport_projection_autre : ''));
addField($pdf, utf8_decode('Taille de l\'Image'), $taille_image . ($taille_image_autre ? ' - ' . $taille_image_autre : ''));
addField($pdf, utf8_decode('Système de Projection'), $systeme_projection . ($systeme_projection_autre ? ' - ' . $systeme_projection_autre : ''));
addField($pdf, utf8_decode('Haut-parleur'), $haut_parleur . ($haut_parleur_autre ? ' - ' . $haut_parleur_autre : ''));
addField($pdf, utf8_decode('Poids'), $poids . ($poids_autre ? ' - ' . $poids_autre : ''));
addField($pdf, utf8_decode('Connexions'), $connexions);

// Enregistrement du PDF
$pdf->Output('F', 'téléchargement/Description_Video_Projecteur.pdf');
?>
