<?php
require('fpdf186/fpdf.php'); // Inclure la bibliothèque FPDF

// Vérifiez si les données sont envoyées via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupération des données du formulaire
    $type = $_POST['type'];
    $nombre_prises = $_POST['nombre-prises'];
    $nombre_prises_autre = isset($_POST['nombre-prises-autre']) ? $_POST['nombre-prises-autre'] : '';
    $protection_surtension = $_POST['protection-surtension'];
    $courant_max = $_POST['courant-max'];
    $courant_max_autre = isset($_POST['courant-max-autre']) ? $_POST['courant-max-autre'] : '';
    $certifications = $_POST['certifications'];
    $certifications_autre = isset($_POST['certifications-autre']) ? $_POST['certifications-autre'] : '';
    $couleur = $_POST['couleur'];
    $couleur_autre = isset($_POST['couleur-autre']) ? $_POST['couleur-autre'] : '';
    $longueur_cordon = $_POST['longueur-cordon'];
    $longueur_cordon_autre = isset($_POST['longueur-cordon-autre']) ? $_POST['longueur-cordon-autre'] : '';

    // Création du PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Description de la Prise Parafoudre', 0, 1, 'C');
    $pdf->Ln(10);

    // Définir la police pour le contenu
    $pdf->SetFont('Arial', '', 12);

    // Remplir le PDF avec les données du formulaire
    $pdf->Cell(0, 10, 'Type: ' . $type, 0, 1);
    $pdf->Cell(0, 10, 'Nombre de Prises: ' . ($nombre_prises === 'plus' ? $nombre_prises_autre : $nombre_prises), 0, 1);
    $pdf->Cell(0, 10, 'Protection Contre Surtension: ' . $protection_surtension, 0, 1);
    $pdf->Cell(0, 10, 'Courant Maximum: ' . ($courant_max === 'autre' ? $courant_max_autre : $courant_max), 0, 1);
    $pdf->Cell(0, 10, 'Certifications: ' . ($certifications === 'autre' ? $certifications_autre : $certifications), 0, 1);
    $pdf->Cell(0, 10, 'Couleur: ' . ($couleur === 'autre' ? $couleur_autre : $couleur), 0, 1);
    $pdf->Cell(0, 10, 'Longueur du Cordon: ' . ($longueur_cordon === 'autre' ? $longueur_cordon_autre : $longueur_cordon), 0, 1);

    // Générer le PDF et l'envoyer au navigateur
    $pdf->Output('I', 'description_prise_parafoudre.pdf');
} else {
    echo 'Aucune donnée reçue.';
}
?>
