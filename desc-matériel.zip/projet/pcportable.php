<?php
require('fpdf186/fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
    function Footer()
    {
        $this->SetY(-20);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10,'page'.$this->PageNo(), 0, 0, 'C');
    }

}



$pdf = new PDF();

$pdf->SetTitle('Descriptif matériel');

$pdf->AddPage();


// Title
$pdf->SetFont('Arial', '', 16);

$pdf->Cell(0, 10, 'ROYAUME DU MAROC PROVINCE DE FQUIH BEN SALAH ', 0, 1, 'L');
$pdf->SetFont('Arial', 'BU', 16);

$pdf->Cell(0, 10, 'Computer description', 0, 1, 'C');


// Retrieve form data
function output($option,$input){
    if ($_POST[$option]=='autre'){
        return isset($_POST[$input]) ? $_POST[$input] : '';
    
    }
    else{
        return isset($_POST[$option]) ? $_POST[$option] : '';
    
    
    }

}
$type_pc_portable=output('type_pc_portable','other_type_pc_portable');
$marque_pc_portable=output('marque_pc_portable','other_marque_pc_portable');
$processeur=output('processeur','other_processeur');

$ram=output('ram','other_ram');
$disque_dur=output('disque_dur','other_disque_dur');
$ecran=output('ecran','other_ecran');


$carte_graphique=output('carte_graphique','other_type_pc_portable');
$systeme_exploitation=output('systeme_exploitation','other_systeme_exploitation');
$clavier=output('clavier','other_clavier');







$h=15;
$w=60;
$pdf->SetFont('Arial', 'BU', 12);
$pdf->ln();
$liste=array(
'type_pc_portable'=>$type_pc_portable,
'marque_pc_portable'=>$marque_pc_portable,
'processeur'=>$processeur,
'ram'=>$ram,
'disque_dur'=>$disque_dur,
'ecran'=>$ecran,
'carte_graphique'=>$carte_graphique,
'systeme_exploitation'=>$systeme_exploitation,
'clavier'=>$clavier,






);


foreach ($liste as $x=>$y){
    $pdf->SetX(30);

    $pdf->SetFont('Arial', 'B', 12);

    $pdf->Cell($w, $h,$x ,1,0,'C');
    $pdf->SetFont('Arial', '', 12);

    $pdf->Cell($w, $h,$y ,1,1,'C');

}

$pdf->Ln();
$pdf->Output('I', '');
$pdf->Output('F', 'Téléchargement/PcPortable.pdf');
echo 'PDF has been generated successfully.';
?>
