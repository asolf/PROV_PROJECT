<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test1";


// Créer une connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Récupérer les données du formulaire
$marque = $_POST['marque'];
$processeur = $_POST['processeur'];

// Préparer la requête SQL
$sql = "INSERT INTO exemple2 (marque, processeur) VALUES ('$marque', '$processeur')";

// Exécuter la requête
if ($conn->query($sql) === TRUE) {
    echo "Nouvelle entrée ajoutée avec succès";
} else {
    echo "Erreur: " . $sql . "<br>" . $conn->error;
}

// Fermer la connexion
$conn->close();
?>
