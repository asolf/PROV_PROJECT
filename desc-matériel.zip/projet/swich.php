<?php
require('fpdf186/fpdf.php');

// Récupération des données du formulaire
$brand = $_POST['brand'] == 'Autre' ? $_POST['brandOther'] : $_POST['brand'];
$model = $_POST['model'] == 'Autre' ? $_POST['modelOther'] : $_POST['model'];
$ports = $_POST['ports'] == 'Autre' ? $_POST['portsOther'] : $_POST['ports'];
$speed = $_POST['speed'] == 'Autre' ? $_POST['speedOther'] : $_POST['speed'];
$type = $_POST['type'] == 'Autre' ? $_POST['typeOther'] : $_POST['type'];
$quantity = $_POST['quantity'];

// Initialisation du PDF
$pdf = new FPDF();
$pdf->AddPage();

// Titre du document
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Description du Switch', 0, 1, 'C');
$pdf->Ln(10);

// Informations générales
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(50, 10, 'Marque :', 0, 0);
$pdf->Cell(0, 10, $brand, 0, 1);

$pdf->Cell(50, 10, utf8_decode('Modèle :'), 0, 0);
$pdf->Cell(0, 10, $model, 0, 1);

$pdf->Cell(50, 10, 'Nombre de ports :', 0, 0);
$pdf->Cell(0, 10, $ports, 0, 1);

$pdf->Cell(50, 10, 'Vitesse (Gbps) :', 0, 0);
$pdf->Cell(0, 10, $speed, 0, 1);

$pdf->Cell(50, 10, 'Type de switch :', 0, 0);
$pdf->Cell(0, 10, $type, 0, 1);

$pdf->Cell(50, 10, utf8_decode('Quantité souhaitée :'), 0, 0);
$pdf->Cell(0, 10, $quantity, 0, 1);

$pdf->Ln(10);

// Générer le PDF
$pdf->Output('F', 'téléchargement/description_switch.pdf');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "history";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert document details into the database
$document_name = mysqli_real_escape_string($conn, 'description_switch.pdf');
$document_link = mysqli_real_escape_string($conn, 'téléchargement/description_switch.pdf');

$sql = "INSERT INTO document_history (document_name, document_link) VALUES ('$document_name', '$document_link')";
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Display the document history
$result = mysqli_query($conn, "SELECT * FROM document_history ORDER BY download_date DESC");

echo "<ul>";
while ($row = mysqli_fetch_assoc($result)) {
    echo "<li><a href='" . $row['document_link'] . "'>" . $row['document_name'] . "</a> - Downloaded on " . $row['download_date'] . "</li>";
}
echo "</ul>";

// Close the connection
$conn->close();
?>
