
<?php
//require('fpdf186/fpdf.php');
require('fpdf186/fpdf.php');
$marque = $_POST['marque'];
$processeur = $_POST['processeur'];

$pdfName = $_POST['pdfName'];
$pdfAddress = $_POST['pdfAddress'];
$pdfAddress2 = $_POST['pdfAddress2'];
$pdfCity = $_POST['pdfCity'];
$pdfState = $_POST['pdfState'];
$pdfZip = $_POST['pdfZip'];
$pdfCountry = $_POST['pdfCountry'];
$pdfPhone = $_POST['pdfPhone'];
$pdfEmail = $_POST['pdfEmail'];


// $pdf = new FPDF('P','mm','A4');
$pdf = new FPDF('P','mm','A4');
// A4 = 210mm × 297mm

$pdf->SetTitle('FPDF Tutorial');
$pdf->SetAutoPageBreak(true, 10);//10:start new page once the content is over 10mm

$pdf->AddPage();

$pdf->SetFont('Arial','BU',16);//BOLD_UNDERLINE_FONT-SIZE:16

//create a table where insert title 190mm height:5,C:center 0:border-none 1:start a new lign after title
$pdf->Cell(190 ,5,'This is the title', 0, 1, "C");

$pdf->Image('favicon.png',20,25,-400);
/*the logo is going to be insert 
20mm from the left and
25 from the top
if the img is big use negative size*/

$pdf->Ln(40);//insert space 40mm bellow the title

$pdf->SetFont('Arial','B',16);


$pdf->Cell(18, 5,"Marque:", 0, 0);//first 0 means border
$pdf->SetFont('Arial', '', 16);
$pdf->MultiCell(40, 5, $marque, 0, "L");
//L:left
//first 0 means border

$pdf->Ln(4);//space

/*$pdf->SetFont('Arial','B',16);
$pdf->Cell(25, 5,"Address:", 0, 0);
$pdf->SetFont('Arial', '', 16);
$pdf->MultiCell(80, 5, $pdfAddress, 0, "L");

$pdf->Ln(4);

$pdf->SetFont('Arial','B',16);
$pdf->Cell(28, 5,"Address2:", 0, 0);
$pdf->SetFont('Arial', '', 16);
$pdf->MultiCell(60, 5, $pdfAddress2, 0, "L");

$pdf->Ln(4);

$pdf->SetFont('Arial','B',16);
$pdf->Cell(13, 5,"City:", 0, 0);
$pdf->SetFont('Arial', '', 16);
$pdf->MultiCell(60, 5, $pdfCity, 0, "L");

$pdf->Ln(4);

$pdf->SetFont('Arial','B',16);
$pdf->Cell(16, 5,"State:", 0, 0);
$pdf->SetFont('Arial', '', 16);
$pdf->MultiCell(60, 5, $pdfState, 0, "L");

$pdf->Ln(4);

$pdf->SetFont('Arial','B',16);
$pdf->Cell(11, 5,"Zip:", 0, 0);
$pdf->SetFont('Arial', '', 16);
$pdf->MultiCell(40, 5, $pdfZip, 0, "L");

$pdf->Ln(4);

$pdf->SetFont('Arial','B',16);
$pdf->Cell(24, 5,"Country:", 0, 0);
$pdf->SetFont('Arial', '', 16);
$pdf->MultiCell(60, 5, $pdfCountry, 0, "L");

$pdf->Ln(4);

$pdf->SetFont('Arial','B',16);
$pdf->Cell(20, 5,"Phone:", 0, 0);
$pdf->SetFont('Arial', '', 16);
$pdf->MultiCell(60, 5, $pdfPhone, 0, "L");

$pdf->Ln(4);

$pdf->SetFont('Arial','B',16);
$pdf->Cell(18, 5,"Email:", 0, 0);
$pdf->SetFont('Arial', '', 16);
$pdf->MultiCell(80, 5, $pdfEmail, 0, "L");

$pdf->Ln(15);
/*create a table 
12:size of 1st column
71:size of 2nd column
ainsi de suite jusqu´à la derniere colonne

*/
/*$pdf->SetWidths(array(12,71,25,40,42));
for($i = 1; $i <= 40; $i++) {
    $pdf->Row(array(1, 2, 3, 4, 5));
    //the content of columns
}
/* name the file test.dpf
I:in lign to the browser*/
$pdf->Output('I', 'Test.pdf');
?>
