<?php
require('fpdf186/fpdf.php');

// Création de l'objet FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Titre du document
$pdf->Cell(0, 10, 'Formulaire de Description de Régulateur de Tension', 0, 1, 'C');

// Remplissage des données du formulaire
$pdf->SetFont('Arial', '', 12);

// Nom du produit
$pdf->Cell(0, 10, 'Nom du produit : ' . htmlspecialchars($_POST['product-name']), 0, 1);

// Type de régulateur
$pdf->Cell(0, 10, 'Type : ' . htmlspecialchars($_POST['type']), 0, 1);

// Plage de tension d'entrée
$pdf->Cell(0, 10, 'Plage de tension d\'entrée : ' . htmlspecialchars($_POST['input-voltage-range']), 0, 1);

// Plage de tension de sortie
$pdf->Cell(0, 10, 'Plage de tension de sortie : ' . htmlspecialchars($_POST['output-voltage-range']), 0, 1);

// Puissance
$power = htmlspecialchars($_POST['power']);
if ($power === 'autre') {
    $power .= ' (Précisé comme : ' . htmlspecialchars($_POST['custom-power-range']) . ')';
}
$pdf->Cell(0, 10, 'Puissance : ' . $power, 0, 1);

// Type de connecteur
$connectorType = htmlspecialchars($_POST['connector-type']);
if ($connectorType === 'autre') {
    $connectorType .= ' (Précisé comme : ' . htmlspecialchars($_POST['custom-connector-type-text']) . ')';
}
$pdf->Cell(0, 10, 'Type de connecteur : ' . $connectorType, 0, 1);

// Technologie
$pdf->Cell(0, 10, 'Technologie : ' . htmlspecialchars($_POST['technology']), 0, 1);

// Autonomie
$pdf->Cell(0, 10, 'Autonomie : ' . htmlspecialchars($_POST['autonomy']), 0, 1);

// Protection
$protection = htmlspecialchars($_POST['protection']);
if ($protection === 'autre') {
    $protection .= ' (Précisé comme : ' . htmlspecialchars($_POST['custom-protection-text']) . ')';
}
$pdf->Cell(0, 10, 'Protection : ' . $protection, 0, 1);

// Dimensions
$pdf->Cell(0, 10, 'Dimensions (L x l x H) : ' . htmlspecialchars($_POST['dimensions']), 0, 1);

// Poids
$pdf->Cell(0, 10, 'Poids : ' . htmlspecialchars($_POST['weight']), 0, 1);

// Génération du fichier PDF
$pdf->Output('F', 'téléchargement/Regulateur_de_Tension.pdf');
?>
